import type { SVGProps } from 'react';

/** Full-name identity. Use currentColor for the ink and a theme-aware accent. */
export function RecalloWordmark({ className, ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="-2 -2 533 127" width="142" height="34" role="img" aria-label="Recallo" className={className} {...props}>
      <path fill="currentColor" fillRule="evenodd" transform="translate(0 0)" d="M0 120V0H45C76 0 92 15 92 39C92 58 82 71 65 76L95 120H72L44 79H19V120Z M19 17V62H43C63 62 73 54 73 39C73 24 63 17 43 17Z" />
      <path fill="currentColor" fillRule="evenodd" transform="translate(103 0)" d="M80 84H18C20 100 30 108 44 108C56 108 64 104 71 97L81 110C71 119 59 123 43 123C16 123 0 106 0 79C0 52 16 35 42 35C67 35 81 52 81 77Z M18 70H63C61 56 54 50 42 50C30 50 21 57 18 70Z" />
      <path fill="currentColor" fillRule="evenodd" transform="translate(193 0)" d="M78 49L66 62C60 54 53 51 44 51C28 51 18 62 18 79C18 97 28 108 44 108C54 108 61 104 67 96L79 108C70 118 59 123 43 123C17 123 0 105 0 79C0 53 17 35 43 35C58 35 70 40 78 49Z" />
      <path fill="currentColor" fillRule="evenodd" transform="translate(281 0)" d="M5 46C15 39 28 35 43 35C68 35 81 47 81 69V120H64L63 110C56 119 46 123 32 123C12 123 0 112 0 95C0 77 14 66 38 66H63C62 55 55 50 42 50C30 50 21 54 13 59Z M63 80H40C25 80 18 85 18 94C18 104 24 109 35 109C51 109 63 99 63 85Z" />
      <path fill="var(--recallo-logo-accent, #B74830)" fillRule="evenodd" transform="translate(374 0)" d="M0 0H18V104H27V120H0Z M36 0H54V104H62V120H36Z" />
      <path fill="currentColor" fillRule="evenodd" transform="translate(443 0)" d="M0 79C0 52 17 35 43 35C69 35 86 52 86 79C86 106 69 123 43 123C17 123 0 106 0 79Z M18 79C18 98 27 108 43 108C59 108 68 98 68 79C68 61 59 50 43 50C27 50 18 61 18 79Z" />
    </svg>
  );
}
